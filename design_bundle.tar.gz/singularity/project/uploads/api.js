export const API_URL = import.meta.env.VITE_API_URL || "https://singularity-87br.onrender.com";
